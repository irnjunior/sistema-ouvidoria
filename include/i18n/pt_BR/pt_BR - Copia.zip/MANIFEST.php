<?php return array (
  'Build-Date' => 'Mon, 28 Mar 16 20:25:58 +0000',
  'Build-Version' => 'v1.9.13-1-g54a70b5',
  'Language' => 'pt_BR',
  'Id' => 'lang:pt_BR',
  'Last-Revision' => '2016-03-28 14:51-0400',
  'Version' => 145919,
);